<?php
session_start();

if (!isset($_SESSION["messages"])) {
    $_SESSION["messages"] = array();
}

if (isset($_GET["message"]) && !empty($_GET["message"])) {
    array_push($_SESSION["messages"], $_GET["message"]);
}

if (!empty($_SESSION["messages"])) {
    echo json_encode($_SESSION["messages"]);
}
?>